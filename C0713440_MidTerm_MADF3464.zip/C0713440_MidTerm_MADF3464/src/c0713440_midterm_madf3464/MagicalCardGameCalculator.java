/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0713440_midterm_madf3464;

/**
 *
 * @author macstudent
 */
public class MagicalCardGameCalculator implements MagicalCardGameInterface

{
   
    static public String[][] getFirstShuffleResult(MagicalCardGameModel magicalCardGameModel)
    {
        String[][] holdFirstShuffle=new String[3][3];
        
        
        String[][] cardsList=magicalCardGameModel.getCardList();
        int row=0;
        int col=0;
        if(magicalCardGameModel.getFirstShuffleColPos().equalsIgnoreCase("C1"))
        
        
        
        {
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    if(j==1){
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++)
            {
                for(int j=0;j<3;j++)
                {
                    if(j==0)
                    {
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++)
                
                
                {
                    if(j==2)
                    
                    {
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
        }
        
        else if(magicalCardGameModel.getFirstShuffleColPos().equalsIgnoreCase("C2"))
        
        
        {
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++)
                
                {
                    if(j==0){
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++)
                
                {
                    if(j==1){
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++)
                
                
                
                {
                    if(j==2){
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
        }else if(magicalCardGameModel.getFirstShuffleColPos().equalsIgnoreCase("C3"))
        
        
        {
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++)
                
                
                {
                    if(j==1){
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++)
            
            
            {
                for(int j=0;j<3;j++)
                
                {
                    if(j==2)
                    
                    {
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++)
                
                
                {
                    if(j==0)
                    
                    {
                        holdFirstShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
        }
        return holdFirstShuffle;
    }
    
    /*
     Getting Second Shuffle
     */
    public String[][] getSecShuffleResult(MagicalCardGameModel magicalCardGameModel)
    {
        String[][] holdSecShuffle=new String[3][3];
        String[][] cardsList=magicalCardGameModel.getFirstShuffle();
        int row=0;
        int col=0;
        if(magicalCardGameModel.getSecShuffleColPos().equalsIgnoreCase("C1"))
        {
        }
        else if(magicalCardGameModel.getFirstShuffleColPos().equalsIgnoreCase("C2"))
        
        
        {
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++)
                
                
                {
                    if(j==0){
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++){
                    if(j==1){
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++)
                
                
                {
                    if(j==2)
                    
                    
                    {
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
        }else if(magicalCardGameModel.getFirstShuffleColPos().equalsIgnoreCase("C3"))
        
        {
            for(int i=0;i<3;i++)
            
            {
                for(int j=0;j<3;j++)
                
                {
                    if(j==1)
                    
                    {
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    if(j==2){
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    if(j==0){
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
        }else {
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    if(j==1){
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    if(j==0){
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
            row++;
            col=0;
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    if(j==2){
                        holdSecShuffle[row][col]=cardsList[i][j];
                        col++;
                    }
                }
            }
        }
        return holdSecShuffle;
    }
}




/*
declaring the result 
*/


