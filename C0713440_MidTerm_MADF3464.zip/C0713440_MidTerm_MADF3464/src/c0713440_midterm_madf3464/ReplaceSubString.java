/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0713440_midterm_madf3464;

/**
 *
 * @author macstudent
 */
public class ReplaceSubString 
{
   public static void main(String args[]){
      String str = "the dog jumped over the fence";
     System.out.println( str.replaceAll("the", "that") );
   }
}

