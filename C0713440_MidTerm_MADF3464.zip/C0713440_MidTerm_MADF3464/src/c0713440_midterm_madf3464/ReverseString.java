/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0713440_midterm_madf3464;

/**
 *
 * @author macstudent
 */
public class ReverseString
        
        
  {
    public static void main(String[] args)
    {
        String input = "Swetha";
 byte [] strAsByteArray = input.getBytes();
 
  byte [] result = 
   new byte [strAsByteArray.length];
 
        
  for (int i = 0; i<strAsByteArray.length; i++)
  result[i] = 
    strAsByteArray[strAsByteArray.length-i-1];
 
        System.out.println(new String(result));
    }
}

