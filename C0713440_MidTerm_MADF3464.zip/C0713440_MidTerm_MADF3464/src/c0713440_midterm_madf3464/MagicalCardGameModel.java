/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0713440_midterm_madf3464;

/**
 *
 * @author macstudent
 */
public class MagicalCardGameModel 
{
 
String firstShuffleColPos;
String secShuffleColPos;



String [][]cardList=null;
String [][]firstShuffle=null;
String [][]secShuffle=null;
String guessedCard;

    public void setFirstShuffleColPos(String firstShuffleColPos) {
        this.firstShuffleColPos = firstShuffleColPos;
    }

    public void setSecShuffleColPos(String secShuffleColPos) {
        this.secShuffleColPos = secShuffleColPos;
    }

    public void setCardList(String[][] cardList) {
        this.cardList = cardList;
    }

    public void setFirstShuffle(String[][] firstShuffle) {
        this.firstShuffle = firstShuffle;
    }

    public void setSecShuffle(String[][] secShuffle) {
        this.secShuffle = secShuffle;
    }

    public void setGuessedCard(String guessedCard) {
        this.guessedCard = guessedCard;
    }

    public String getFirstShuffleColPos() {
        return firstShuffleColPos;
    }

    public String getSecShuffleColPos() {
        return secShuffleColPos;
    }

    public String[][] getCardList() {
        return cardList;
    }

    public String[][] getFirstShuffle() {
        return firstShuffle;
    }

    public String[][] getSecShuffle() {
        return secShuffle;
    }

    public String getGuessedCard() {
        return guessedCard;
    }

   public String getFinalResult() {
       return getFinalResult();
   }

    public MagicalCardGameModel(String firstShuffleColPos, String secShuffleColPos, String guessedCard) {
        this.firstShuffleColPos = firstShuffleColPos;
        this.secShuffleColPos = secShuffleColPos;
        this.guessedCard = guessedCard;
    }
   
   
   }

        
        
    




    


