/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c0713440_midterm_madf3464;

 import java.util.Arrays;
import java.util.HashMap;

public class  MostFrequent 
{
  
    public static void main(String[] args) {
      
        char result = 0;
        
        char[] arr1 = new char[]{1, 2, 3, 4, 5, 5, 6, 7, 8, 4, 6, 5};
        char[] arr2 = new char[]{1, 2, 3, 4, 5, 5, 6, 7, 8, 4, 6, 5};
       
        printResult(arr1, result);
        System.out.println();
       
        printResult(arr2, result);
    }
    
    private static void printResult(char[] arr, char result) {
        System.out.println(Arrays.toString(arr));
        if (result == -1) {
            System.out.println("All elements are same ");
        } else {
            System.out.println(("Most frequent number : " + result));
        }
    }}
   
    
